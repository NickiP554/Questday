# QuestDay MVP

Eine installierbare PWA für Quests, XP, Levels, Coins, Streaks und eigene Rewards.

## Schnellstart

1. Installiere Node.js (LTS) und VS Code.
2. Öffne diesen Ordner in VS Code.
3. Für einen lokalen Test reicht ein einfacher Webserver. Mit Node:
   - `npx serve .`
   - dann die angezeigte lokale URL öffnen.
4. Für die Installation auf Android im Browser "Zum Startbildschirm hinzufügen" / "App installieren" wählen.

## Wichtig
Diese MVP-Version speichert Daten lokal im Browser. Das ist absichtlich einfach gehalten. Für ein öffentliches Produkt sollten Accounts, Cloud-Sync, Datenbank, Analytics und Zahlungen als nächste Phase ergänzt werden.

## Ziel
Erst echte Nutzung und Retention beweisen, dann Premium und Store-Launch ausbauen.
