package com.questday.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    int xp=0, level=1, coins=0;
    TextView stats;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.rgb(245,247,251)); t.setTextSize(size);
        t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }

    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(124,92,255)); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        showApp();
    }

    void showApp(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(15,17,23));

        TextView title=tv("⚔ QUESTDAY",28);
        title.setGravity(Gravity.CENTER);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(70)));

        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14),dp(5),dp(14),dp(5));
        ScrollView scroll=new ScrollView(this); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setPadding(dp(4),dp(5),dp(4),dp(5));
        String[] names={"🏠","⚔","🎁","👤"};
        for(String n:names){
            Button x=btn(n); nav.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));
            if(n.equals("🏠")) x.setOnClickListener(v->home());
            if(n.equals("⚔")) x.setOnClickListener(v->quests());
            if(n.equals("🎁")) x.setOnClickListener(v->rewards());
            if(n.equals("👤")) x.setOnClickListener(v->profile());
        }
        root.addView(nav);
        setContentView(root);
        home();
    }

    void clear(){ content.removeAllViews(); }

    void card(String text){
        TextView c=tv(text,18); c.setBackgroundColor(Color.rgb(24,28,37));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(90)); p.setMargins(0,dp(7),0,dp(7));
        content.addView(c,p);
    }

    void home(){
        clear();
        stats=tv("Level "+level+"   •   "+xp+" XP   •   🪙 "+coins,20);
        content.addView(stats);
        card("🔥 Streak\nHalte deine Serie am Leben!");
        Button q=btn("⚔ Quests öffnen"); q.setOnClickListener(v->quests()); content.addView(q);
        card("🎯 Dein Ziel\nErledige Aufgaben, sammle XP und steige im Level auf.");
    }

    void quests(){
        clear();
        content.addView(tv("DEINE QUESTS",23));
        addQuest("📚 30 Minuten lernen",40,15);
        addQuest("🧹 Eine wichtige Aufgabe erledigen",30,10);
        addQuest("🏃 20 Minuten Bewegung",35,12);
        addQuest("📖 15 Minuten lesen",25,8);
    }

    void addQuest(String name,int gainXp,int gainCoins){
        Button q=btn(name+"   +"+gainXp+" XP");
        q.setOnClickListener(v->{
            xp+=gainXp; coins+=gainCoins;
            while(xp>=need()) { xp-=need(); level++; Toast.makeText(this,"LEVEL UP! Level "+level,Toast.LENGTH_SHORT).show(); }
            Toast.makeText(this,"Quest abgeschlossen: +"+gainXp+" XP, +"+gainCoins+" Coins",Toast.LENGTH_SHORT).show();
            quests();
        });
        content.addView(q,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    int need(){ return 100+(level-1)*50; }

    void rewards(){
        clear();
        content.addView(tv("BELohnUNGSSHOP",23));
        addReward("🎮 30 Minuten Gaming",100);
        addReward("🎬 Filmabend",250);
        addReward("🍕 Lieblingsessen",400);
        addReward("🏆 Eigene Belohnung",500);
        TextView c=tv("🪙 Deine Coins: "+coins,20); content.addView(c);
    }

    void addReward(String name,int cost){
        Button r=btn(name+"   "+cost+" 🪙");
        r.setOnClickListener(v->{
            if(coins>=cost){ coins-=cost; Toast.makeText(this,"Belohnung eingelöst!",Toast.LENGTH_SHORT).show(); rewards(); }
            else Toast.makeText(this,"Noch nicht genug Coins.",Toast.LENGTH_SHORT).show();
        });
        content.addView(r,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    void profile(){
        clear();
        content.addView(tv("DEIN PROFIL",23));
        card("⚔ Level "+level+"\nXP bis zum nächsten Level: "+(need()-xp));
        card("🪙 "+coins+" Coins");
        card("🏆 Fortschritt\nDeine QuestDay-Reise beginnt jetzt.");
        Button reset=btn("Fortschritt zurücksetzen");
        reset.setOnClickListener(v->{xp=0;level=1;coins=0;profile();});
        content.addView(reset);
    }
}
