# QuestDay Android

Komplettes kleines Android-Projekt für QuestDay.
Features: Quests, XP, Level, Coins, Belohnungsshop und Profil.

Build:
1. Projekt in Android Studio oder einen Android-kompatiblen Cloud-Build-Dienst importieren.
2. Gradle synchronisieren.
3. `app` als APK bauen.

Hinweis: Dieses Projekt ist die erste native Android-Basis. Cloud-Sync, Login, Push-Benachrichtigungen und Monetarisierung können als nächste Version ergänzt werden.
